import React from 'react';

function HomePage(){
    return (
        <>
            <h1>ACA Code Deployment Main </h1>
            <p> Please select one of the options above to deploy code </p>
        </>
    )
}

export default HomePage;