import React from 'react';
import CreateQATCodeDrop from '../components/QATPetCodeDrop'

function QAT_Pet_CodeDrops(){
    return (
        CreateQATCodeDrop()
    )
}


export default QAT_Pet_CodeDrops;