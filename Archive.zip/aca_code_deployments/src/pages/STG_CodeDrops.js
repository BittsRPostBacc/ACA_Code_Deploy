import React from 'react';

function STG_CodeDrops(){
    return (
        <>
            <h1>STG_CodeDrops</h1>
        </>
    )
}


export default STG_CodeDrops