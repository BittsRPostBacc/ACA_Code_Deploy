const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://test:test@cluster0.fqddjac.mongodb.net/?retryWrites=true&w=majority', {
    useNewURLParser: true,
    useUnifiedTopology: true
}, err => err ? console.log(err) :
    console.log('Connected successfully to Mongo')
);

